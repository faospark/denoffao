The goal of this project is to establish an ideal folder structure for translation mods for Final Fantasy IX on Steam. 
Currently, most translation mods powered by Memoria rely on Memoria's "Import Text" function. Unlike regular mods, this 
method requires manual installation of .string files in the game’s root folder. Ideally, translation mods should be 
placed in independent folders, similar to other mods for the game.

This project provides folders and .mes/text files structured to be compatible with the latest version of Memoria. All 
text files are based on the U.S. version of the game's translation, or at least assume that version as the baseline. 
The majority of the .mes files are located in the FF9_Data\embeddedasset\text\us\field folder, where I’ve made every 
effort to locate all relevant U.S. English dialogue .mes files.

Additionally, I’ve included tpsheets with append=true to increase compatibility, particularly if you intend to edit 
in-game sprites that contain text.

Please note: This project is not yet fully complete. There are still some parts of the game where the corresponding 
files have not been located. However, most of it is functional and can be tested by placing the LanguageTranslation 
folder in the game’s root directory.

If you want to contribute feel free to tag us on the moogles and mod server 