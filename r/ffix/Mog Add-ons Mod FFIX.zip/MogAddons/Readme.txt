oooooooooooooo#%#..oo*#oo,% %ooooooooooo
oooooooooo,.   . ..  . ,%%&.*ooooooooooo
oooooooo.    ...  .... . %*,%ooooooooooo
ooooooo.  ....... ..   .  .,.ooooooooooo
oooooo&.  ... .. . ..... .,,,#oooooooooo
oooo%...%%&.,/..,%,.......,,,,oooooooooo
oooo...*#*%............,,,,,,ooooooooooo
oooo................,,,,,,,*,%%###//////
ooooo%../*........,*,,,,,,,%%%%#&////#oo
oooooooo#/......,,,,,,,,*%%%%&///#/#oooo
oooo%/....**........,*%#%##////,/ooooooo

███╗░░░███╗░█████╗░░██████╗░  ░█████╗░██████╗░██████╗░░░░░░░░█████╗░███╗░░██╗░██████╗
████╗░████║██╔══██╗██╔════╝░  ██╔══██╗██╔══██╗██╔══██╗░░░░░░██╔══██╗████╗░██║██╔════╝
██╔████╔██║██║░░██║██║░░██╗░  ███████║██║░░██║██║░░██║█████╗██║░░██║██╔██╗██║╚█████╗░
██║╚██╔╝██║██║░░██║██║░░╚██╗  ██╔══██║██║░░██║██║░░██║╚════╝██║░░██║██║╚████║░╚═══██╗
██║░╚═╝░██║╚█████╔╝╚██████╔╝  ██║░░██║██████╔╝██████╔╝░░░░░░╚█████╔╝██║░╚███║██████╔╝
╚═╝░░░░░╚═╝░╚════╝░░╚═════╝░  ╚═╝░░╚═╝╚═════╝░╚═════╝░░░░░░░░╚════╝░╚═╝░░╚══╝╚═════╝░

+------------------------+
|-- Table of Contents  --|
+------------------------+
MA-1: Description
MA-2: Installation Instructions
MA-3: Changelog
MA-4: List of Features
MA-5: Guide, Usage and Recommendations

***********************
|| MA-1: Description ||
***********************
A Library / Collection of Gameplay Tweaks, Graphical enhancement , Button Support and Many more
This Mod started out pretty small but overtime has gone to be a major collection powered by 
THE MEMORIA ENGINE. 

:: WHO is this mod for ::
This mod is perfect for players who love to customize and aren't afraid to change the look and feel of the game.
It's also ideal for gamers who don't have much time but want to re-experience the game in a fresh way. If you're a 
purist or a difficulty junkie, this mod might not be for you though ive recently added some challenge tweaks
It's designed to give you a sense of power and freedom rather than struggle. With a focus on providing options rather 
than limitations, this mod lets you tailor your gaming experience to your liking

:: History ::
This mod began as an unreleased Dissidia Final Fantasy Opera Omnia portrait mod with a dark UI and a personal button 
mod, as I have a habit of creating button mods. It was the first complete button mod, unlike most others that lacked 
shoulder button support. Why am I sharing this information? It’s something I'll explain a little later. The bottom 
line is that as the features of Memoria progressed, I was able to create mods in a way that could be shared without 
fully editing the main source files.

More Here
https://www.nexusmods.com/finalfantasy9/mods/31 

:: Contact :: 
https://steamcommunity.com/id/faospark/


*************************************
|| MA-2: Installation Instructions ||
*************************************
:: Installation Using this Zip file and options ::
- Make sure you have Memoria v2022.11.11 or higher
- Unzip the downloaded files and place the MogAddons folder on the game root 
- Launch the game. This will open the Memoria launcher 
- click "Mod Manager"on the top right size. this will open the mod manager 
- find the Mog addons  item on the right side window. and tick the box
- To customize/ activate submods click the drop down menu to configure what ever submods you like once done Launch 

:: Alternative method : Installation via memoria launcher / mod manager ::
- Open Memoria Launcher
- Click Install Mods 
- Click Browse Catalog
- Click Mog Addons 
- Click the download arrow on the right of the launcher
- Click installed Mods and tick the box thats it 

::To Activate mods::
- Launch the game and click Mod manager on the top right side of the launcher 
- Look for Mog Add-ons on the list of installed mods and make sure it is placed high on the list order 
(use the arrow buttons on the left of the ui to put mog add-ons higher in the mod order) 
- click the configure button on the right side pane around the description area of the mod 
- this will activate the drop down list, select which mods do you like and tick the box on right to activate them 
- then launch the game and you are done 

*********************
|| MA-3: Changelog ||
*********************
Version changes over the years. 

Updates for 3.7 series
:: 3.7.4 ::
- Changed Default installed mods and are follows 
 : Portraits are now Default Extended 
 : Darker UI still as a default . Activate Default gray and blue on options
 : Colored Maps
 : Changed PS4 Gloss to PSX Simple for buttons 
- Freya' High Jump now learned through Javelin and Mythril Spear
- Aero-aga and Water-aga spells can now be used as single targets 
- Removed redundant files 
- compressed images using lossless scaling reducing file size
- Updated preview files

:: 3.7.3 ::
- Another full revamp of Readme.txt file 
- fixed Spanish Translation of Black Magic of Vivi 
- Made No Menu background as optional
- added Better Airship controls (now can be turned off)
- added Text Helper on Synth Shops 
- Added X8 Exp Requirement, 8x gil and NO EXP but with AP Gain
- Added challenge section on submods
- Restored drop list separators this time with no bugs
- Fixed a lot of Typos
- added Marcus DFFOO Portrait 
- Added Beatrix stat support 

:: 3.7.2 ::
- fixed Mod Manager issues
- Added guide for battle enhancements on Readme file
- Added DV's Animation correction for Steiner's Abilities 
- NEW : faster speed and Better Controls for SS Invincible  when manually driving (On By Default)
- replaced preview file and link  

:: 3.7.1 ::
-fixed texture options not working correctly 

:: 3.7 ::
Characters Enhancements
 - Added Passive for Zidane : - Pillage - Boosts damage of thievery
 - Added -Aero-,-Quake-,-Water- up to their Aga levels To Vivi   
 - Added New -Swrd Mag- skills for Steiner 
 - New Active Ability -Photon Beam- Increases Garnet Utility in early parts of the game  
 - Splits -Titan- and -Fenir- in to two independent summons for Eiko (replaces old swap method)
 - New Support Ability - Tensai - Makes Amaranth learn abilities and Level up extremely fast
- - Gameplay
 - 1 Ability Gem now compatible with Alternate fantasy
 - Added option Remove Auto Potion and replace it with 5% HP and AP 
 - Added 8xp
 - Fix DoubleXP requirement 
- - Graphical 
 - Added option Menu Background Choices: Tantalus and Chocobo, Defaults to black
 - Added option Title Screen Concept art loop
 - New Portraits of all variants for Lani, Frately and Mikoto [Just in case she is added in game] 
 - New 3d Portraits for Cinna and Marcus
 - Added Dffoo portraits support for Pluto knight Zidane and White mage Garnet
 - Restored Original versions of the assets and not the compressed ones
 - Unified shared assets on base mod to reduce repeated textures on variants
- - General
 - Reorganized folders of some sub mods 
 - Removed Random card drop because it is now part of DV's Card Mod 
 - Fixed Colored Maps Bug 

:: Collective notes from 3.5 - 3.6.1 ::
 - Added Hot fixes for recent release of Moguri
 - another significant file reduction 	
 - Added Recreation Title Screen  
 - Added Pixel remaster Darker Ui
 - Added Requested NA SNES Controller
 - Quina's can now Eat at 50% enemy hp
 - Quina's can Cook at 100% enemy Hp (though can still miss)
 - Steiner can Now equip Save the Queen
 - Fixed 1 gem cost skill for Alternate fantasy 
 - Fixed exp conflict with one of the submods
 - Marked reduced file size through compression and now using Append mode
 - Fixed AP Tweak Bug 
 - added deferred Tweak 2x Item drop 
 - added Alternative colored world Maps
 - added Millennial Decay as default for Eiko's summon skill 
 - added Freya Jump do 3x damage 
 - added Resistance to zombie and virus status
 - replaced file preview url and preview file
 - striped extra slash declared submod folders

:: 3.4 ::
-Fixed formula for AP and EXP tweaks 
-increased card limit to total to 999
-added tweaks : 2x AP , 2x Gil , 4x Gil 
-added get random card after battle
-added alternative title screen 
-added triple triad matt 
-added remove mist on disc4

:: 3.3 ::
-Added 4x AP gain
-Added 99 AP gain
-Added 2x+ EXP gain
-Added 4x+ EXP gain
-Added NO EXP AND AP GAIN

:: 3.2 ::
- Added double exp and halved ability gems

:: 3.1 ::  
- Added 1 Gem Compatibility with Alternate Fantasy
- Replaced Amaranth's Opera Omnia Portrait

:: 3.0 :: 
-Split default feature of halved EXP and 1 Gem passive ability to ech submod
- Replaced Preview file on local folders 
- Bump compatibility Up to the v2023.06.11 version of memoria

:: 2.9 ::
- Added requested custom Blank DFFOO portrait , replaced  Marcus and Cinna 
- Bump compatibility to the recent version of memoria 

:: 2.8 ::
- Added Disable features : Disable 1 ability gem and havled exp as the ability to revert to XBOX prompts  
- removed 2 versions on this bundle. Please refer/download to version 2.6 on nexus for compatibility

:: 2.7 ::
- added Fratley, Lani, Kuja Portraits. added compatibility with the latest Memoria
- fully compatible with playbale character mod 
- and many more


****************************
|| MA-4: List of Features ||
****************************
* Might have Missed out somethings. 
:: Primary Game Tweaks ::
- Gameplay Tweaks: 2x, 4x , 8x [ Ability , EXP and Gil ]
- Make Ability Gems Require only 1 gem (available since April 5 2022) or Half of the cost 
- Make EXP requirements cut in half
- No mist on Disc 4 
- Add immunity to Zombie and Virus status 
- 2x item received after battle 

:: UI related features ::
- Multiple Alternative Title Screen
- Alternate Title Loop
- Alternate menu back ground
-- UI
- Darker UI for Gray and Classic Dialogue Boxes
- Flat UI for gray and classic (New)
- Darker UI frame from The Pixel Remaster (New)
- - Portraits
- Full support for Playable Character Mod by Tirlititi
- Opera Omnia Style Portraits (default)
- Upscaled PS1 Portrait Artworks 

:: Button prompts ::
- PlayStation Vanilla prompts (the closest to the game stock UI)
- ( Dualshock 4) PlayStation Gloss prompts (a glossier type and default install)
- ( Dualsense )PS5 white button prompts - Pixel Type Button Prompts
- SNES North American one [via request] (NEW)

:: Character Enhancements NEW In Version 3.7 ::
- Zidane: Gains Pillage Support Abilty .
- Vivi: Gains access to the following spells that can target all enemies: Aero, Quake, and Water, 
  each upgradable to their AGA / 3rd tier level.
- Steiner: Can equip Save The Queen and access all of Vivi's new black magic spells mentioned above.
- Quina: The power of their two primary abilities is enhanced: Eat can be used at 75% enemy health, 
  and Cook can be used at 100% enemy health.
- Freya: Gains a High Jump support ability, making Jump deal triple the HP damage output.
- Garnet: Gains a new spell called Photon Beam, a medium-type Holy damage spell available early in 
  the game to enhance her usability.
- Amaranth: Gains the Tensai support ability. As a late recruit, this ability allows him to learn 
  abilities eight times faster than other characters.
- Eiko : The summons Titan and Fenrir are now independent. Moonstone grants Fenrir, while Sapphire grants Titan.


********************************************
|| MA-5: Guide, Usage and Recommendations ||
********************************************
|| General Rules on Tweaks||
Mog Add-ons should be placed above most mods for it to work properly 
Pick only 1 of the same tweak. Ex: select only 1 of Exp tweak. 2x and 4x Exp wont stack. 
for as long as there is not overlap within the activated sub mods you wont have a problem

|| Default Install ||
Mods that are turned on by default : Opera Omnia Portraits , Darker UI , PSX button gloss, Recreation title Screen. 
Question : I want the game to look like as vanilla as possible ? 
Answer : Simply activate the following mod : Portraits : Default Extended Cast , Dialog box : Default , Buttons Either 
you pick Default X-box or Simple PS.  

|| Memoria Compatibility Report says Conflict||
A new feature of Memoria is its compatibility report.while this tools is effective in detecting conflicts of overlapping
mods... it has a problem on accurately detecting conflicts on several mod files that can stack ex: abilityfeatures.txt, 
any .mes files etc. such files can contain code that stack .Most tweaks found in Mog Add-ons Harnesses the power of 
abilityfeatures.txt. so kindly ignore warnings if it involves those files.

|| Portraits: ||
All version of portraits mods fully support Beatrix, Cinna, Marcus, Blank, Kuja, Fratley , Lani and even Mikoto though
she is not available in any mod yet 

|| Buttons: ||
Recent version of Memoria now natively supports various controllers how ever the game lacks texture support for such 
different controllers. current themes supported are PS5, PS4, PSX , SNES , Pixel and Xbox. I take pride of the fact that 
Mog Add-ons was one of the first to actually support shoulder buttons. it something that mods that came before this
lacked. Just make sure to pick one of the available options

|| Challenge Mods ||
if you want some challenge , i recently highlighted mods that make either makes you not level up or levelling up is much 
harder. this can make your grinding a lot harder.  

|| Character Enhancements Guide ||
These collection of sub-mods  enhances or increases utility of characters at certain points of the story.
This started as incorporating wind magic to Vivi that quickly grew to something a lot bigger than what it supposed to be 
All of the new character enhancements are submods that can be activated individually. 
Simply find the item , Equip them , learn the ability and you are done. 
Mod Compatibility : Extended character pack, Tantalus (Vanilla) and Beatrix mod. The modification below will override
your abilities with Alternate Fantasy. its still usable most likely will have unintended side effect with AF. 

[1] Zidane - Pillage is a support ability that essentially cuts the time in half of making thievery strong by doubling 
    the output damage
    Bronze Vest (Pillage)
[2] Vivi - Have access to the spells below that target all enemies : Aero, Quake and Water up to their 3rd tier level  
    Leather Hat (Aero)
    Feather Hat (Aera)
    Robe of Lords(Aeroga)
    Mage Staff (Quake)
    Magic Armlet (Quakera)
    Adaman Hat (Quakaga)
    Wrist (Water)
    Magus Hat (Watera)
    N-Kai Armlet (Waterga)
[3] Steiner - Gets to Equip Save The Queen and has Access to all new black magic spells of Vivi above
[4] Quina - Inherently changes the power of his 2 prime abilities Eat At 75% Enemy Health Cook At 100% Enemy Health 
[5] Freya - High Jump Support Ability : makes Jump do 3x HP Damage output . 
[6] Garnet - Gives a Garnet a Medium type Holy damage spell at the early parts of the game to make more usable 
    Steepled Hat (Photon Beam)
[7] Amaranth - Since he is a late recruit this ability makes him learn abilities 8 times the speed of other characters
    Cat’s Claws (Tensai)
[8] Eiko - Split of Titan and Fenrir as independent summons. Moonstone now had Fenrir while Sapphire has Titan 
    Moonstone (Fenrir)
    Sapphire (Titan)
[9] Beatrix - a recent addition and a Port / version based off the beatrix mods. I've Added this for you to not to
    lose progress in case you deactivate alternate fantasy     

Summary of Item Changes 
Character   Item            (Ability)       [Type]
Zidane      Bronze Vest     (Pillage)       [Support Ability]
Vivi        Leather Hat     (Aero)          [Active Ability : Black Magic]
Vivi        Feather Hat     (Aera)          [Active Ability : Black Magic]
Vivi        Robe of Lords   (Aeroga)        [Active Ability : Black Magic]
Vivi        Mage Staff      (Quake)         [Active Ability : Black Magic]
Vivi        Magic Armlet    (Quakera)       [Active Ability : Black Magic]
Vivi        Adaman Hat      (Quakaga)       [Active Ability : Black Magic]
Vivi        Wrist           (Water)         [Active Ability : Black Magic]
Vivi        Magus Hat       (Watera)        [Active Ability : Black Magic]
Vivi        N-Kai Armlet    (Waterga)       [Active Ability : Black Magic]
Garnet      Steepled Hat    (Photon Beam)   [Active Ability : White Magic]
Amaranth    Cat’s Claws     (Tensai)        [Support Ability] 
Eiko        Moonstone       (Fenrir)        [Active Ability : Summpn]
Eiko        Sapphire        (Titan)         [Active Ability : Summon]

*************************************
|| MA-6: Acknowledgment and Credits||
*************************************
- Rcer for Fratley portrait 
- artbreeder ... who ever added Kuja 
- BenteJam for Lani 
- Most Especially to Snouz, DV, and Tirlititi. 

And Moogles and Mods 
https://discord.gg/bSnpVBV