A tiny mod the replaces items and spell names with modern Final Fantasy Naming Convention. 
Perfect for players that were introduced to the franchise post FFX.

Additional Features: 
2025-06-27
- Added Option of to Have Freija and Salamander as Default names . 

Quina's pronoun - Them or They instead of S/he 
New Icons for Elements (This is where Kupo Ui Suite Got it )
Extended Field Scripts for additional icons on tutorials

Recent Log: 
Nova Dragon -> Shinryu
Maliris ->  Marilith 
Dragon Knight -> Dragoon
Swd Magic -> Spellblade

Item -> Items 
Equip -> Gear 
Config. -> Settings 
Addon -> Accessory

Soft -> Golden Needle 
Supersoft -> Platinum Needle
Echo Screen -> Echo Herbs
Magic Tag -> Holy Water 
Panacea -> Poisona 
Life -> Raise 
Full Life -> Araise 
Demi -> Gravity 

Darkness -> Blind
Annoynment-> Calming Bell
Swd Art -> Sword Art
Blk Mag -> Black Magic 
Wht Mag -> White Magic 
Grn Mag -> Green Magic
Dbl White -> DualCast
Dbl Black -> TwinCast
Slot -> Folder
item -> Inventory
Card -> Cards
Config -> Settings
Arrange -> Sort 
NUM -> Quantity 
Evade -> Evasion
Magic Def -> Magic Defence
Magic Eva -> Magic Evasion

Key Items description are centered

The mod works for the US and UK versions. 
If you want to change things for your language, feel free to request

Place the mod folder like so in the game root . 
like so 
steamapps\common\FINAL FANTASY IX\KupoModernLabels
Then activate the mod via the Memoria mod manager