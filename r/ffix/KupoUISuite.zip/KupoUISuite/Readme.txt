=====================
Kupo UI Suite
===================== 
The First User Interface Modding Suite for FFIX Steam. This mod allows you to change the ff:
Dialogue UI, Menu, Title Screen, Menu Bg , World Map , Title loop , Triple Triad Mat. 
Also Included Text UI helpers Synthesis menus. 

=====================
Notes and Instructions
===================== 
"Utilize the preview tooltip in the manager to familiarize yourself with the available options 
you can activate for the game. Mods like Controller Packs and Portrait Packs should be placed 
above this mod, while this mod should be positioned above any type of gameplay mod.

=====================
Changelog
=====================
2025-06-09 - 2025-07-19
- Major Rearrangement of features.
- added New Gem Icons Options 
- Improved compatibility of Elemental Icons with DV's QOL of Iifa mod 
- A new theme : Modern II 
  a modern theme that has transparent borders 
- restored highlight in Modern theme, removed dividers in modern theme  
- added Key Item Icons 
- Added more Full Background options (5)
- Added Restore SquareSoft Logo Option 
- Added Support for newer PCP (Baku, Ruby, Gerome , Mikoto)
- revamped default controller buttons in line with the recent version of Kupo Buttons
- Added 3 text options
- Added Wide Screen Samples for Title menu 
- Change sprite implementation of 2 title screen options 
- Removed forced Memoria.ini on Title Loop Option 
- Optimized / reduced file sizes of image assets. 

2025-05-23
- Added Support for Playable Character Pack 
- Fixed Card Background for Dynamic Option 
- Added additional Background for Dynamic Option
- added more previews 

2024-12-22
- Added Dynamic Full BG Background theme 
- Removed unpublished options  

2024-12-16
- Fixed Remedy Icon
- Added Extended Icons for other modders to use
- Revamped Triple Triad Theme
- Added Key Item Bg Option
- Fixed various small bugs causing it to not work properly

2024-11-12
- Fixed typo on Append method on textures
- Added new UI cursor sound
- Fixed/removed unnecessary gradients in some options

2024-11-06
- Added Origins title screen
- Fixed several bugs on textures
- Relaxed mod description

2024-11-01
- Improved alignment of default cursor
- Fixed missing assets of default controller

2024-10-31
- Added Modern UI theme (Translucent theme), replaces DarkerUIPR
- Added Full Background Menu Background
- Added Scroll UI Theme
- Disabled gradients and highlight text by default for compatibility
- New Key Item background

4.1.0
- Added Borderless Option
- Added No UI Divider
- Added Base Cinna Portrait
- Converted to use assets with extensions
- Added Append property

=====================
Extended Icons Guide
===================== 
A set Icons not found in game , feel free the following. 
Replaced Icon are stil their place holder in game.
To use the icons : [ICON=271]
_______________________________________________
| No. | New Icon     | Replaced Icon   | Code |
|-----|--------------|-----------------|------|
| 1   | Fire         | icon_x          | 271  |
| 2   | Ice          | icon_y          | 272  |
| 3   | Thunder      | icon_b          | 273  |
| 4   | Wind         | icon_a          | 274  |
| 5   | Earth        | icon_minus      | 257  |
| 6   | Water        | icon_plus       | 276  |
| 7   | Holy         | icon_racing_01  | 277  |
| 8   | Shadow       | icon_racing_02  | 278  |
| 9   | Memory Card  | virtual_map     | 250  |
⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻⎻



Acknowledgment :
For the Pixel art 

azeresh
https://www.deviantart.com/azereshi/art/FF9-Sprite-Showcase-Round-2-826476646

Hozure
https://www.deviantart.com/hozure/art/414-Pixel-Tantalus-Troupe-706973110