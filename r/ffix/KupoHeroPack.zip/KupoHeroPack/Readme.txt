Key Features
ALL Characters:
- Grants resistance to Zombie (via Auto-Life) and Virus (via Anti-Body).
- Replaces Auto-Potion with +5% HP and MP.

Transportation:
- Increases Airship and Chocobo speed.

|| Character Enhancements Guide ||
This collection of sub-mods enhances or improves character utility at key points in the story.  
This mod began as a simple addition of wind magic to Vivi but quickly expanded into something much larger.  
All new character enhancements are optional sub-mods that can be activated individually.  
Simply find the item that teaches the ability, equip it, learn the ability, and you're set.  

Mod Compatibility: Compatible with Playable Character Pack, Tantalus (Vanilla), and Beatrix Mod.  
A layer of compatibility has been added with Alternate Fantasy , though not perfect but serviceable 

[1] Zidane:
    - Pillage: A support ability that halves the time needed to make thievery strong by doubling the output damage.
    - Bronze Vest (Pillage)

[2] Vivi: Gains access to the following spells:
    - Leather Hat (Aero)
    - Feather Hat (Aera)
    - Robe of Lords (Aeraga)
    - Mage Staff (Quake)
    - Magic Armlet (Quakera)
    - Adaman Hat (Quakaga)
    - Wrist (Water)
    - Magus Hat (Watera)
    - N-Kai Armlet (Waterga)
    - Mace of Zeus (Ultima)

[3] Steiner:
    - Can equip Save The Queen and has access to all new black magic spells of Vivi listed above.

[4] Quina:
    - Increases the effectiveness of their prime abilities:
        - Eat: Works at 50% enemy health. 
        - Cook: Works at 100% enemy health.
        - for Alternate Fantasy - 90% percent for Eat . Cook Dbl Blue Magic in AF 

[5] Freya:
    - High Jump Support Ability: Increases Jump damage output to 3x HP.
    - High Jump can be learned through Javelin and Mythril Spear
    - Kain's Lance is now a drop from boss Taharka.

[6] Garnet:Gains 3 new Holy Spells
    - Dagger (Lumi)
    - Steepled Hat (Lumira)
    - Whale Whisker (Luminaga)

[7] Amarant:
    - Learns abilities at 8 times the speed of other characters due to being a late recruit.
        - Cat's Claws (Tensai)

[8] Eiko:
    - Splits Titan and Fenrir into independent summons.
        - Moonstone (Fenrir)
        - Sapphire (Titan)

[9] Beatrix:
    - A recent addition based on the Beatrix mod. Added to prevent losing progress if Alternate Fantasy is deactivated.

Summary of Item Changes 
Character   Item                    (Ability)       [Type]
Zidane      Bronze Vest             (Pillage)       [Support Ability]
Vivi        Leather Hat             (Aero)          [Active Ability : Black Magic]
Vivi        Feather Hat             (Aera)          [Active Ability : Black Magic]
Vivi        Robe of Lords           (Aeraga)        [Active Ability : Black Magic]
Vivi        Mage Staff              (Quake)         [Active Ability : Black Magic]
Vivi        Magic Armlet            (Quakera)       [Active Ability : Black Magic]
Vivi        Adaman Hat              (Quakaga)       [Active Ability : Black Magic]
Vivi        Wrist                   (Water)         [Active Ability : Black Magic]
Vivi        Magus Hat               (Watera)        [Active Ability : Black Magic]
Vivi        N-Kai Armlet            (Waterga)       [Active Ability : Black Magic]
Vivi        Mace of Zeus            (Ultima)        [Active Ability : Black Magic]
Freya       Javelin                 (High Jump)     [Support Ability]
Freya       Mythril Spear           (High Jump)     [Support Ability]
Garnet      Steepled Hat, Dagger    (Lumi)          [Active Ability : White Magic]
Garnet      Steepled Hat,           (Lumira)        [Active Ability : White Magic]
Garnet      Whale Whiskers          (Lumiraga)      [Active Ability : White Magic]
Amaranth    Cat’s Claws             (Tensai)        [Support Ability] 
Eiko        Moonstone               (Fenrir)        [Active Ability : Summon]
Eiko        Sapphire                (Titan)         [Active Ability : Summon]


|| Changelog ||
2025-06-25 - 2025-06-30
- Expanded Photons: Now known as the Lumi spell series for Garnet (Holy single-target spells).
- Enhanced Quina's abilities in Alternate Fantasy: Eat now works at 90% enemy HP; Cook is not included in AF.
- Fixed Save the Queen abilities for Alternate Fantasy compatibility.
- Added status effects for Wind (Confusion) and Earth (Trouble) spells in Alternate Fantasy.
- Corrected Italian translation for Vivi's spells.
- Special: Visit Daguerreo and speak to the character name changer for new features (note: not all users utilize Kupo modern labels).

2025-05-31
- added compatibility layer 

2025-02-11
- Added Kain Lance as an item drop ( Taharka )

2025-01-13
- Reduced Amaranth's exp gain
- Created an option for identical daggers

2024-12-22
- Added Zidane same dagger feature 
- Added Phoenix Pinion usable outside battle 
- Added ability Cura on an item for Kuja to learn

11-12-24
- Added World Sound submods

10-27-24
- Pillage, Added double items gained and gil 
- Photons, renamed from Photon Beam
- Vivi , All skill replaced ID number to avoid collision with other mods. 
- Added localization for No Potion 
- Transportation enhancements (Moved from another Kupo mod) 
 
Moogles and Mods 
https://discord.gg/bSnpVBV